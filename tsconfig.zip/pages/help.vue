<template>
    <div>
        <h1>HELP PAGE</h1>
    </div>
</template>

<script>
</script>
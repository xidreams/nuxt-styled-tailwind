<template>
    <div>
        <h1>CONTACT PAGE</h1>
    </div>
</template>

<script>
</script>
<template>
    <div id="divP1">

        <Header />
        <NuxtPage />
        <Footer />

    </div>
</template>

<script>
    import Header from '@/components/Header.vue';
    import Footer from '@/components/Footer.vue';

    export default {
        components: {
            Header,
            Footer,
        },
    };
</script>

<style>
    #divP1 {
        text-align: center;
        margin: 0 auto;
        width: 90%;
        /* Default width */
    }

    #divP1 div {
        text-align: left;
        /* Left align text in child divs */
    }

    @media (max-width: 800px) {
        #divP1 {
            width: 100%;
            /* Full width for screens <= 800px */
        }
    }

    @media (min-width: 3812px) {
        #divP1 {
            width: 3300px;
            /* Fixed width for screens > 3812px */
        }
    }


</style>

<template>
    <footer class="bg-white shadow mt-4">
        <div style="height: 100px; background-color: #e4e4e4; clear: both;">
            <p>© 2024 My Website. All rights reserved.</p>
        </div>
    </footer>
</template>

<script>
    export default {};
</script>

<style scoped>
    /* Add any styles for the footer here */
</style>
